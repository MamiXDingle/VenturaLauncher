msgbox "Bienvenue sur GenHackzd by Nawakk"
inputbox "Ecrivez le pseudo fortnite de la personne que vous souhaitez vous vanger."
msgbox "Cliquez  sur ok pour continuer."