msgbox "Welcome to GenHackz V2"
msgbox "Version plus efficace que la V1."