msgbox "quelles compte a hacker ?"
inputbox "Ecrivez le pseudo"
msgbox "Compte detecte."
inputbox "Ecrivez votre Adresse IP pour etablir une connexion au compte du joueurs."