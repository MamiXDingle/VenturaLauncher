msgbox "Un programme a empeche la connexion au serveur."
msgbox "essayez de voir le programme qui empeche et réessayer."