color d

start welcome.vbs

timeout 10

start startGenHackzCod.bat

timeout 60

color 6

dir/s

dir/s

dir/s

dir/s

dir/s

dir/s

dir/s

dir/s

dir/s

dir/s

dir/s

dir/s

dir/s

dir/s

dir/s

start genhackz.py

start clon.vbs