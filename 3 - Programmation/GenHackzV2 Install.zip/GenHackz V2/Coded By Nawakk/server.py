from asyncio import to_thread
from concurrent.futures import process
from distutils.ccompiler import gen_lib_options
from http.client import CannotSendRequest
from json import detect_encoding
from ssl import Options
from wsgiref.simple_server import server_version
from xmlrpc import server
from xmlrpc.client import ServerProxy


start server 
detect_encoding server_version
start gen_lib_options
Options open ServerProxy
    detect_encoding to_thread process
            assert_never
                CannotSendRequest